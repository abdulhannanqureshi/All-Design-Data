Please refer to the wiki pages for the [change log](https://github.com/Mottie/Keyboard/wiki/Log).
